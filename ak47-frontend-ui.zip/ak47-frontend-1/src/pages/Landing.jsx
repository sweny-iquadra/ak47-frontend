import React from 'react';
import { useNavigate } from 'react-router-dom';
import { HERO_CONTENT, FEATURES } from '../constants';
import { Header, SearchBar, FeatureCard } from '../components';

const Landing = () => {
  const navigate = useNavigate();
  
  const handleSearch = (query) => {
    navigate('/chat', { state: { searchQuery: query } });
  };

  const renderFeatureIcon = (iconColor) => {
    const icons = {
      blue: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
        </svg>
      ),
      green: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
        </svg>
      ),
      purple: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
        </svg>
      )
    };
    return icons[iconColor] || icons.blue;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      {/* Hero Section */}
      <main className="relative">
        <div className="relative h-96 md:h-[500px] lg:h-[600px]">
          {/* Background Image */}
          <div 
            className="absolute inset-0 bg-cover bg-center bg-no-repeat"
            style={{
              backgroundImage: `url('${HERO_CONTENT.backgroundImage}')`
            }}
          >
            <div className="absolute inset-0 bg-black bg-opacity-40"></div>
          </div>

          {/* Hero Content */}
          <div className="relative z-10 flex flex-col items-center justify-center h-full px-4 sm:px-6 lg:px-8">
            <div className="text-center backdrop-blur-sm bg-white/10 rounded-3xl p-8 md:p-12 border border-white/20 shadow-2xl animate-fade-in-up">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4 tracking-tight animate-slide-in-left">
                {HERO_CONTENT.title}
              </h1>
              <p className="text-lg md:text-xl text-white/90 mb-8 font-medium animate-slide-in-right animation-delay-200">
                {HERO_CONTENT.subtitle}
              </p>

              <div className="animate-fade-in animation-delay-400">
                <SearchBar 
                  onSearch={handleSearch}
                  placeholder="Hi! What can I help you find today?"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Features Section */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12 animate-fade-in-up">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                How I Help You Shop Better
              </h2>
              <p className="text-lg text-gray-600">
                Chat with me like a friend - I'll handle the heavy lifting
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {FEATURES.map((feature, index) => (
                <div key={feature.id} className={`animate-slide-in-up animation-delay-${(index + 1) * 200}`}>
                  <FeatureCard
                    icon={renderFeatureIcon(feature.iconColor)}
                    title={feature.title}
                    description={feature.description}
                    iconColor={feature.iconColor}
                  />
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* About A³ Section */}
        <section className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div className="animate-slide-in-left">
                <h2 className="text-3xl font-bold text-gray-900 mb-6">
                  Meet A³: Anything, Anywhere, Anytime
                </h2>
                <p className="text-lg text-gray-600 mb-6">
                  A³ is your intelligent shopping companion powered by advanced AI technology. 
                  Whether you're looking for the perfect gift, comparing prices across thousands 
                  of retailers, or discovering new products tailored to your preferences, I'm here 
                  to make your shopping experience effortless and enjoyable.
                </p>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="flex-shrink-0 w-5 h-5 bg-green-100 rounded-full flex items-center justify-center mt-0.5">
                      <svg className="w-3 h-3 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"></path>
                      </svg>
                    </div>
                    <p className="text-gray-600">
                      <span className="font-semibold">Natural Language Understanding:</span> Just tell me what you need in plain English
                    </p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="flex-shrink-0 w-5 h-5 bg-green-100 rounded-full flex items-center justify-center mt-0.5">
                      <svg className="w-3 h-3 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"></path>
                      </svg>
                    </div>
                    <p className="text-gray-600">
                      <span className="font-semibold">Real-time Price Monitoring:</span> I track prices across multiple platforms 24/7
                    </p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="flex-shrink-0 w-5 h-5 bg-green-100 rounded-full flex items-center justify-center mt-0.5">
                      <svg className="w-3 h-3 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"></path>
                      </svg>
                    </div>
                    <p className="text-gray-600">
                      <span className="font-semibold">Personalized Recommendations:</span> I learn your preferences to suggest better products
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="animate-slide-in-right">
                <div className="bg-gradient-to-br from-amber-50 to-blue-50 rounded-2xl p-8 shadow-lg">
                  <h3 className="text-xl font-bold text-gray-900 mb-4">Why Choose A³?</h3>
                  <div className="space-y-4">
                    <div className="bg-white rounded-lg p-4 shadow-sm">
                      <h4 className="font-semibold text-gray-900 mb-2">🚀 Lightning Fast</h4>
                      <p className="text-sm text-gray-600">Get instant results from thousands of products across multiple retailers</p>
                    </div>
                    <div className="bg-white rounded-lg p-4 shadow-sm">
                      <h4 className="font-semibold text-gray-900 mb-2">💰 Save Money</h4>
                      <p className="text-sm text-gray-600">Automatically find the best deals and notify you of price drops</p>
                    </div>
                    <div className="bg-white rounded-lg p-4 shadow-sm">
                      <h4 className="font-semibold text-gray-900 mb-2">🎯 Smart Filtering</h4>
                      <p className="text-sm text-gray-600">Advanced filters help you find exactly what you're looking for</p>
                    </div>
                    <div className="bg-white rounded-lg p-4 shadow-sm">
                      <h4 className="font-semibold text-gray-900 mb-2">🔒 Secure & Private</h4>
                      <p className="text-sm text-gray-600">Your shopping history and preferences are kept completely private</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="py-16 bg-gradient-to-r from-amber-500 to-amber-600">
          <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8 animate-fade-in-up">
            <h2 className="text-3xl font-bold text-white mb-4">
              Ready to Transform Your Shopping Experience?
            </h2>
            <p className="text-xl text-amber-100 mb-8">
              Join thousands of smart shoppers who save time and money with A³
            </p>
            <button
              onClick={() => navigate('/chat')}
              className="bg-white text-amber-600 px-8 py-4 rounded-lg font-semibold text-lg hover:bg-gray-50 transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
              Start Shopping with A³
            </button>
          </div>
        </section>

        
      </main>
    </div>
  );
};

export default Landing;