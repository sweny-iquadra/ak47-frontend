import React from 'react';

const Logo = ({ size = 'default', showText = true }) => {
  const sizeClasses = {
    small: 'w-10 h-10',
    default: 'w-16 h-16',
    large: 'w-20 h-20'
  };

  const textSizeClasses = {
    small: 'text-lg',
    default: 'text-2xl',
    large: 'text-4xl'
  };

  return (
    <div className="flex items-center space-x-3 logo-container group">
      {/* Modern Cube Logo */}
      <div className="relative">
        <svg 
          width="64" 
          height="64" 
          viewBox="0 0 48 48" 
          className={`logo-svg transition-all duration-300 ${sizeClasses[size]} group-hover:scale-105`}
          fill="none"
        >
          {/* 3D Cube Structure */}
          <g className="cube-container">
            {/* Top face */}
            <path 
              d="M12 16 L24 10 L36 16 L24 22 Z" 
              fill="url(#topFace)" 
              stroke="rgba(255,255,255,0.2)" 
              strokeWidth="0.5"
            />

            {/* Left face */}
            <path 
              d="M12 16 L12 32 L24 38 L24 22 Z" 
              fill="url(#leftFace)" 
              stroke="rgba(255,255,255,0.2)" 
              strokeWidth="0.5"
            />

            {/* Right face */}
            <path 
              d="M24 22 L24 38 L36 32 L36 16 Z" 
              fill="url(#rightFace)" 
              stroke="rgba(255,255,255,0.2)" 
              strokeWidth="0.5"
            />

            {/* Letter A with proper cutout - more prominent */}
            <path 
              d="M18 30 L24 16 L30 30 L27.5 30 L26.5 27 L21.5 27 L20.5 30 Z M22.5 23.5 L25.5 23.5 L25 25 L23 25 Z" 
              fill="#00B4D8" 
              fillRule="evenodd"
              stroke="#0077B6"
              strokeWidth="0.6"
              className="letter-a drop-shadow-sm"
            />
            
            {/* Subtle outline around the A */}
            <path 
              d="M18 30 L24 16 L30 30 L27.5 30 L26.5 27 L21.5 27 L20.5 30 Z M22.5 23.5 L25.5 23.5 L25 25 L23 25 Z" 
              fill="none" 
              stroke="#ffffff"
              strokeWidth="0.3"
              opacity="0.8"
              className="letter-a-outline"
            />
            
            {/* Inner glow for the A */}
            <path 
              d="M18 30 L24 16 L30 30 L27.5 30 L26.5 27 L21.5 27 L20.5 30 Z" 
              fill="none" 
              stroke="#00B4D8"
              strokeWidth="0.8"
              opacity="0.4"
              className="letter-a-glow"
            />
          </g>

          {/* Subtle glow effect */}
          <circle 
            cx="24" 
            cy="24" 
            r="20" 
            fill="none" 
            stroke="url(#glowGradient)" 
            strokeWidth="0.5" 
            opacity="0.3"
            className="group-hover:opacity-60 transition-opacity duration-300"
          />

          {/* Gradient definitions */}
          <defs>
            {/* Top face - lightest */}
            <linearGradient id="topFace" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#E5E7EB" />
              <stop offset="100%" stopColor="#D1D5DB" />
            </linearGradient>

            {/* Left face - medium */}
            <linearGradient id="leftFace" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#9CA3AF" />
              <stop offset="100%" stopColor="#6B7280" />
            </linearGradient>

            {/* Right face - darkest */}
            <linearGradient id="rightFace" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#6B7280" />
              <stop offset="100%" stopColor="#4B5563" />
            </linearGradient>

            {/* Glow effect */}
            <radialGradient id="glowGradient" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#00B4D8" />
              <stop offset="100%" stopColor="transparent" />
            </radialGradient>
          </defs>
        </svg>

        {/* Subtle shadow */}
        <div className="absolute inset-0 rounded-lg bg-gray-900 opacity-10 blur-sm -z-10 transform translate-y-1 group-hover:opacity-20 transition-all duration-300"></div>
      </div>

      {/* Clean brand text */}
      {showText && (
        <div className="flex flex-col brand-text">
          <div className={`font-bold text-gray-800 ${textSizeClasses[size]} tracking-tight`}>
            A³
          </div>
          <div className="text-xs text-gray-500 font-medium tracking-wider uppercase">
            Anything Anywhere Anytime
          </div>
        </div>
      )}
    </div>
  );
};

export default Logo;